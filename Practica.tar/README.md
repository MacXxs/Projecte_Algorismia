# README
## _Pràctica d'Algorismia_
## Instalació
- Només és necessari tenir la llibreria de boost per tal de poder usar els grafs
```sh
sudo apt-get install boost
```

## Execució
- Un cop instalada, si es desitja executar el programa principal cal compilarlo amb el flag -O2 o -O3 i un cop compilat seguir les instruccions d'aquest.
```sh
g++ -O2 -c program.cpp
g++ -o program program.o
```
- Si es vol usar l'script que hem usat per fer obtenir la informació de l'estudi, només cal compilar igual que en el punt anterior l'arxiu program_script.cpp i executar el bash executable.sh de la següent forma
```sh
bash executable.sh param1 param2 param3 param4 param5 param6
```
- On param1 és el tipus de graf (1.Graella, 2.Binomial, 3.Geomètric), param2 és n, param3 és p, param4 és r i param5 és q
